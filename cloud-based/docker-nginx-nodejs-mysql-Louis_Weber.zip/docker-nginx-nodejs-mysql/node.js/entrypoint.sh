#!/bin/bash

cp -r /tmp/node_modules /src/node_modules
nodemon /src/index.js
