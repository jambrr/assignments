apidoc: {
    myapp: {
        src: "rest_api/",
        dest: "apidoc/"
    }
}
